from licofage.kit import *
import os
setparams(False, False, os.environ["WALNUT_HOME"])

s = subst('a->aab, b->cab, c->a')
ns = address(s, "pof")
ns.gen_ns()
ns.gen_word_automaton()
s1 = s
ns1 = ns
for (i,a) in enumerate(ns1.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s1, ns1.ns, **w)
    (parikh - ns1).gen_dfa(f"pofb1p{i}")
s2 = block(s, 2)
ns2 = address(s2, "pofb2")
ns2.gen_ns()
(ns-ns2).gen_dfa("conv_pof_pofb2")
for (i,a) in enumerate(ns2.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s2, ns2.ns, **w)
    (parikh - ns2).gen_dfa(f"pofb2p{i}")
s3 = block(s, 3)
ns3 = address(s3, "pofb3")
ns3.gen_ns()
(ns-ns3).gen_dfa("conv_pof_pofb3")
for (i,a) in enumerate(ns3.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s3, ns3.ns, **w)
    (parikh - ns3).gen_dfa(f"pofb3p{i}")
s4 = block(s, 4)
ns4 = address(s4, "pofb4")
ns4.gen_ns()
(ns-ns4).gen_dfa("conv_pof_pofb4")
for (i,a) in enumerate(ns4.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s4, ns4.ns, **w)
    (parikh - ns4).gen_dfa(f"pofb4p{i}")
s5 = block(s, 5)
ns5 = address(s5, "pofb5")
ns5.gen_ns()
(ns-ns5).gen_dfa("conv_pof_pofb5")
for (i,a) in enumerate(ns5.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s5, ns5.ns, **w)
    (parikh - ns5).gen_dfa(f"pofb5p{i}")

from licofage.kit import *
import os
setparams(False, False, os.environ["WALNUT_HOME"])

s = subst('01/20/0')
ns = address(s, "twi")
ns.gen_ns()
ns.gen_word_automaton()
s1 = s
ns1 = ns
for (i,a) in enumerate(ns1.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s1, ns1.ns, **w)
    (parikh - ns1).gen_dfa(f"twib1p{i}")
s2 = block(s, 2)
ns2 = address(s2, "twib2")
ns2.gen_ns()
(ns-ns2).gen_dfa("conv_twi_twib2")
for (i,a) in enumerate(ns2.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s2, ns2.ns, **w)
    (parikh - ns2).gen_dfa(f"twib2p{i}")
s3 = block(s, 3)
ns3 = address(s3, "twib3")
ns3.gen_ns()
(ns-ns3).gen_dfa("conv_twi_twib3")
for (i,a) in enumerate(ns3.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s3, ns3.ns, **w)
    (parikh - ns3).gen_dfa(f"twib3p{i}")

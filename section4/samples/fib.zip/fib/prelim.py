from licofage.kit import *
import os
setparams(False, False, os.environ["WALNUT_HOME"])

s = subst('01/0')
ns = address(s, "fib")
ns.gen_ns()
ns.gen_word_automaton()
s1 = s
ns1 = ns
for (i,a) in enumerate(ns1.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s1, ns1.ns, **w)
    (parikh - ns1).gen_dfa(f"fibb1p{i}")
s2 = block(s, 2)
ns2 = address(s2, "fibb2")
ns2.gen_ns()
(ns-ns2).gen_dfa("conv_fib_fibb2")
for (i,a) in enumerate(ns2.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s2, ns2.ns, **w)
    (parikh - ns2).gen_dfa(f"fibb2p{i}")
s3 = block(s, 3)
ns3 = address(s3, "fibb3")
ns3.gen_ns()
(ns-ns3).gen_dfa("conv_fib_fibb3")
for (i,a) in enumerate(ns3.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s3, ns3.ns, **w)
    (parikh - ns3).gen_dfa(f"fibb3p{i}")
s4 = block(s, 4)
ns4 = address(s4, "fibb4")
ns4.gen_ns()
(ns-ns4).gen_dfa("conv_fib_fibb4")
for (i,a) in enumerate(ns4.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s4, ns4.ns, **w)
    (parikh - ns4).gen_dfa(f"fibb4p{i}")
s5 = block(s, 5)
ns5 = address(s5, "fibb5")
ns5.gen_ns()
(ns-ns5).gen_dfa("conv_fib_fibb5")
for (i,a) in enumerate(ns5.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s5, ns5.ns, **w)
    (parikh - ns5).gen_dfa(f"fibb5p{i}")
s6 = block(s, 6)
ns6 = address(s6, "fibb6")
ns6.gen_ns()
(ns-ns6).gen_dfa("conv_fib_fibb6")
for (i,a) in enumerate(ns6.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s6, ns6.ns, **w)
    (parikh - ns6).gen_dfa(f"fibb6p{i}")
s7 = block(s, 7)
ns7 = address(s7, "fibb7")
ns7.gen_ns()
(ns-ns7).gen_dfa("conv_fib_fibb7")
for (i,a) in enumerate(ns7.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s7, ns7.ns, **w)
    (parikh - ns7).gen_dfa(f"fibb7p{i}")
s8 = block(s, 8)
ns8 = address(s8, "fibb8")
ns8.gen_ns()
(ns-ns8).gen_dfa("conv_fib_fibb8")
for (i,a) in enumerate(ns8.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s8, ns8.ns, **w)
    (parikh - ns8).gen_dfa(f"fibb8p{i}")
s9 = block(s, 9)
ns9 = address(s9, "fibb9")
ns9.gen_ns()
(ns-ns9).gen_dfa("conv_fib_fibb9")
for (i,a) in enumerate(ns9.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s9, ns9.ns, **w)
    (parikh - ns9).gen_dfa(f"fibb9p{i}")
s10 = block(s, 10)
ns10 = address(s10, "fibb10")
ns10.gen_ns()
(ns-ns10).gen_dfa("conv_fib_fibb10")
for (i,a) in enumerate(ns10.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s10, ns10.ns, **w)
    (parikh - ns10).gen_dfa(f"fibb10p{i}")

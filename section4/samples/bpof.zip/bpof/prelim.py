from licofage.kit import *
import os
setparams(False, False, os.environ["WALNUT_HOME"])

s = subst('a->aab, b->ac, c->aac')
ns = address(s, "bpof")
ns.gen_ns()
ns.gen_word_automaton()
s1 = s
ns1 = ns
for (i,a) in enumerate(ns1.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s1, ns1.ns, **w)
    (parikh - ns1).gen_dfa(f"bpofb1p{i}")
s2 = block(s, 2)
ns2 = address(s2, "bpofb2")
ns2.gen_ns()
(ns-ns2).gen_dfa("conv_bpof_bpofb2")
for (i,a) in enumerate(ns2.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s2, ns2.ns, **w)
    (parikh - ns2).gen_dfa(f"bpofb2p{i}")
s3 = block(s, 3)
ns3 = address(s3, "bpofb3")
ns3.gen_ns()
(ns-ns3).gen_dfa("conv_bpof_bpofb3")
for (i,a) in enumerate(ns3.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s3, ns3.ns, **w)
    (parikh - ns3).gen_dfa(f"bpofb3p{i}")
s4 = block(s, 4)
ns4 = address(s4, "bpofb4")
ns4.gen_ns()
(ns-ns4).gen_dfa("conv_bpof_bpofb4")
for (i,a) in enumerate(ns4.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s4, ns4.ns, **w)
    (parikh - ns4).gen_dfa(f"bpofb4p{i}")
s5 = block(s, 5)
ns5 = address(s5, "bpofb5")
ns5.gen_ns()
(ns-ns5).gen_dfa("conv_bpof_bpofb5")
for (i,a) in enumerate(ns5.alpha):
    w = {'_': 0}
    w[a] = 1
    parikh = address(s5, ns5.ns, **w)
    (parikh - ns5).gen_dfa(f"bpofb5p{i}")
